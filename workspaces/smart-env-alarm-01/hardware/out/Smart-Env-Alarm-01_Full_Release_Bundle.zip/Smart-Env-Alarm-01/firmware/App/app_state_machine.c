/**
 * @file    app_state_machine.c
 * @brief   自动绑定 bsp_pinout.h 外设引脚的非阻塞业务状态机
 */
#include "app_state_machine.h"
#include "bsp_hal.h"

static app_context_t s_app_ctx;

void App_StateMachine_Init(void)
{
    s_app_ctx.current_state       = APP_STATE_BOOT_CHECK;
    s_app_ctx.last_sensor_poll_ms = 0UL;
    s_app_ctx.last_heartbeat_ms   = 0UL;
    s_app_ctx.primary_adc_mv      = 0U;
    s_app_ctx.alarm_threshold_mv  = 2500U;
    s_app_ctx.alarm_latched       = false;
}

void App_StateMachine_Step(void)
{
    uint32_t now = BSP_GetTickMs();

    switch (s_app_ctx.current_state) {
    case APP_STATE_BOOT_CHECK:
        /* 上电自检所有配置的 GPIO/外设通道 */
        if (BSP_ASSIGNED_PIN_COUNT > 0U) {
            BSP_GPIO_WritePin(g_bsp_pinout_table[0].pin_index, false);
        }
        s_app_ctx.current_state = APP_STATE_NORMAL_RUN;
        break;

    case APP_STATE_NORMAL_RUN:
        /* 每 50ms 轮询一次模拟传感器与按键状态 */
        if ((now - s_app_ctx.last_sensor_poll_ms) >= 50UL) {
            s_app_ctx.last_sensor_poll_ms = now;
            s_app_ctx.primary_adc_mv = BSP_ADC_ReadMillivolts(0U);
            if (s_app_ctx.primary_adc_mv >= s_app_ctx.alarm_threshold_mv) {
                s_app_ctx.alarm_latched = true;
                s_app_ctx.current_state = APP_STATE_ALARM_ACTIVE;
            }
        }
        /* 每 500ms 翻转一次运行状态指示灯 */
        if ((now - s_app_ctx.last_heartbeat_ms) >= 500UL) {
            s_app_ctx.last_heartbeat_ms = now;
            if (BSP_ASSIGNED_PIN_COUNT > 1U) {
                BSP_GPIO_TogglePin(g_bsp_pinout_table[1].pin_index);
            }
        }
        break;

    case APP_STATE_ALARM_ACTIVE:
        /* 报警激活态：开启蜂鸣器 PWM (50% 占空比) 并快闪报警灯 */
        BSP_PWM_SetDutyPermille(0U, 500U);
        if (!s_app_ctx.alarm_latched) {
            BSP_PWM_SetDutyPermille(0U, 0U);
            s_app_ctx.current_state = APP_STATE_NORMAL_RUN;
        }
        break;

    case APP_STATE_LOW_POWER_IDLE:
    default:
        BSP_EnterLowPowerSleep();
        s_app_ctx.current_state = APP_STATE_NORMAL_RUN;
        break;
    }
}

app_state_t App_StateMachine_GetState(void)
{
    return s_app_ctx.current_state;
}
